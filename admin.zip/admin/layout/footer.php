</div>
<!-- End of Main Content -->
</div>
<!-- End of Content Wrapper -->
</div>
<!-- End of Page Wrapper -->

<script src="/js//checkbox.js"></script>

<!-- Bootstrap core JavaScript-->
<script src="./layout//vendor/jquery/jquery.min.js"></script>
<script src="./layout//vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

<!-- Core plugin JavaScript-->
<script src="./layout//vendor/jquery-easing/jquery.easing.min.js"></script>

<!-- Custom scripts for all pages-->
<script src="./layout//js/sb-admin-2.min.js"></script>

<!-- Page level plugins -->
<script src="./layout//vendor/chart.js/Chart.min.js"></script>

<!-- Page level custom scripts -->
<script src="./layout//js/demo/chart-area-demo.js"></script>
<script src="./layout//js/demo/chart-pie-demo.js"></script>
</body>

</html>